package com.kushal.Jsp_SpringBoot_Database_MVC;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JspSpringBootDatabaseMvcApplicationTests {

	@Test
	void contextLoads() {
	}

}
