package com.kushal.Jsp_SpringBoot_Database_MVC;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JspSpringBootDatabaseMvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(JspSpringBootDatabaseMvcApplication.class, args);
		System.out.println("MVC Runs");
	}

}
