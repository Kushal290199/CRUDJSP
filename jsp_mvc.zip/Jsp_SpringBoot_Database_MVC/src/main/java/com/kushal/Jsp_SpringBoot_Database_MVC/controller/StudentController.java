package com.kushal.Jsp_SpringBoot_Database_MVC.controller;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.kushal.Jsp_SpringBoot_Database_MVC.model.Student;

@Controller
public class StudentController {
	
	@Autowired
	SessionFactory sf;
	
	@RequestMapping("/")
	public String name() {
		return "student";
	}
	
	@PostMapping("/student")
	public Student save(Student student) {
		Session ss=sf.openSession();
		Transaction tx=ss.beginTransaction();
		
		ss.save(student);
		tx.commit();
		return student;
	}

}
