package com.kushal.Jsp_SpringBoot_Database_MVC.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Student {

	@Id
	int UserId;
	String Password;
	
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Student(int userId, String password) {
		super();
		UserId = userId;
		Password = password;
	}
	public int getUserId() {
		return UserId;
	}
	public void setUserId(int userId) {
		UserId = userId;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	@Override
	public String toString() {
		return "Student [UserId=" + UserId + ", Password=" + Password + "]";
	}
	
	
}
